<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <!-- RWD Viewport -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- CSS -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Hind+Vadodara:700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= "../style/base.css?v=" . time();?>" >
  <link rel="stylesheet" href="<?= "../style/page.css?v=" . time();?>" >
  <link rel="stylesheet" href="<?= "../style/class.css?v=" . time();?>" >

  <!-- Jquery CDN -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  
</head>