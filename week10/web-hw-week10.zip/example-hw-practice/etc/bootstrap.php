<?php

session_start();

require __DIR__ . '/../config/db.php';
require __DIR__ . '/../config/sql.php';

date_default_timezone_set('Asia/Taipei');