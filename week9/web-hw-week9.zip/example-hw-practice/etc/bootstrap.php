<?php

session_start();

require __DIR__ . '/../config/db.php';
require __DIR__ . '/../config/sql.php';
